# CODEX INTEGRATION PROMPT — DeadZone More Settings

Use this prepared pack. Do not decompile the plugin again unless needed.

## Input files
- `more_settings_items.json`
- `lib_ready/deadzone_more_settings_mapping.dart`
- `docs/miui_plugin_more_settings_inventory.md`
- `assets_ready/more_settings_icons/styleswitcher*.png/xml`

## Task
Create a staged `DeadZone More Settings` module from the prepared mapping.

## Hard rules
Do NOT change package/applicationId/namespace/signing/channel/manifest/privapp/native/SystemUI/reference files.
Do NOT add root/su/Superuser/root fallback.
Do NOT rename any extracted key.
Do NOT break existing Statusbar/Battery/Resize modules.

## UI rules
- Every row must have the extracted image/icon chip.
- Switches must be DeadZone-styled.
- Sticky `APPLY CHANGES` button.
- Dark/light mode support.
- Use DeadZone fingerprint everywhere.

## Shared seekbar rule
Any slider/seekbar in this module must use the SAME shared Statusbar/Resize Statusbar seekbar/control style (`DeadZoneAdjustmentRow` / `MezoSourceSeekbarRow`). Do not create a new slider style.

## Safety
Use existing safe setting write path only. If a key cannot apply on this build, save locally and show: `Saved in DeadZone. System apply requires ROM integration.`

## Commit
`feat: prepare deadzone more settings module`
