// Prepared mapping extracted from MiuiSystemUIPlugin / MenuOfMahdi.
// Integrate safely in DeadZone. Do not rename keys.
class DeadZoneMoreSettingItem {
  const DeadZoneMoreSettingItem({
    required this.category,
    required this.label,
    required this.key,
    required this.control,
    required this.iconAsset,
    required this.notes,
  });
  final String category;
  final String label;
  final String key;
  final String control;
  final String iconAsset;
  final String notes;
}

const deadZoneMoreSettingsItems = <DeadZoneMoreSettingItem>[
  DeadZoneMoreSettingItem(category: 'Appearance', label: 'MonetUI', key: 'monetmode', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher.png', notes: 'real key candidate from plugin strings/MenuOfMahdi; verify polarity in ROM'),
  DeadZoneMoreSettingItem(category: 'Appearance', label: 'Glass Effect', key: 'glass_effect', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher1.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Appearance', label: 'Reduced Blur', key: 'bgblur', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher2.png', notes: 'review-needed: same token may also relate to BlendBlur Sliders Icon'),
  DeadZoneMoreSettingItem(category: 'Appearance', label: 'Rounded Corners', key: 'CustomCornerRadius', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher3.png', notes: 'review-needed: key name suggests corner radius behavior'),
  DeadZoneMoreSettingItem(category: 'Appearance', label: 'Compact DPI', key: 'compactdpi', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher4.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Layout Styles', label: '4 Tiles Layout', key: '4tile', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher5.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Layout Styles', label: 'Ladder Layout', key: 'style2', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher6.png', notes: 'real key candidate; label mapping from screenshots'),
  DeadZoneMoreSettingItem(category: 'Large MediaPlayer Styles', label: 'Expanded MediaPlayer', key: 'largemedia', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher7.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Large MediaPlayer Styles', label: 'Lowered MediaPlayer', key: 'largemedia1', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher8.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Card Customisation', label: 'Circle Card Look', key: 'circlecard', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher9.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Card Customisation', label: 'Custom Touch Effect', key: 'cardtouch', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher10.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Preferences', label: 'Enable Sound Tile', key: 'hidesound', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher11.png', notes: 'review polarity: key name says hide but UI says enable'),
  DeadZoneMoreSettingItem(category: 'Preferences', label: 'Small Device Center', key: 'devicesize', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher12.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Preferences', label: 'Square Tiles', key: 'squaretiles', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher13.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Edit Button Styles', label: 'Top Clock + Edit Button', key: 'custom_clock', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher14.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Edit Button Styles', label: 'Default Edit Button', key: 'defaultedit', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher15.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Edit Button Styles', label: 'Traffic Edit Button', key: 'traffic', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher16.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Customize Sliders', label: 'Modern Slider Icons', key: 'slidericon', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher17.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Customize Sliders', label: 'BlendBlur Sliders Icon', key: 'bgblur', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher18.png', notes: "review-needed: shares bgblur with Reduced Blur; don't map twice without polarity test"),
  DeadZoneMoreSettingItem(category: 'Customize Sliders', label: 'Percentage on Sliders', key: 'percent', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher19.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Volume Panel', label: 'Small Volume Panel', key: 'smallvolume', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher20.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Volume Panel', label: 'Lower Volume Panel', key: 'columndown', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher21.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Volume Panel', label: 'Rounded Shortcuts', key: 'circlebuttons', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher22.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Volume Panel', label: 'Hide Dnd & Silent', key: 'HideButtons', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher23.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Volume Panel', label: 'Hide More Icons', key: 'hidemore', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher24.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Advanced Options', label: 'Extended Hyper Island', key: 'extended_hyper_island', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher25.png', notes: 'real key candidate'),
  DeadZoneMoreSettingItem(category: 'Advanced Options', label: 'Extended Power Menu', key: 'powermenu', control: 'switch', iconAsset: 'assets/more_settings_icons/styleswitcher26.xml', notes: 'real key candidate'),
];
