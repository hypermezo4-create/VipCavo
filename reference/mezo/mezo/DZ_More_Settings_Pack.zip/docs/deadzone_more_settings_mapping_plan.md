# DeadZone More Settings Mapping Plan

## Module
Name: `DeadZone More Settings`  
Route suggestion: `/more-settings` or under `More tools`.

## UI direction
Use the screenshot concept but with DeadZone fingerprint:
- dark premium blurred/glass background
- centered panel/card
- title: `More Settings`
- grouped section labels
- large rounded rows
- left image/icon chip for every row
- right premium switch
- sticky `APPLY CHANGES` button
- full light/dark support

## Shared seekbar rule
Any slider/seekbar added to this module must reuse the same shared Statusbar/Resize Statusbar control style:
- `DeadZoneAdjustmentRow` or `MezoSourceSeekbarRow`
- same minus/plus/value pill/reset style
- same Mount/DeadZone accent tokens
- no new random Material slider style

## Suggested groups
1. Appearance
2. Layout Styles
3. Large MediaPlayer Styles
4. Card Customisation
5. Preferences
6. Edit Button Styles
7. Customize Sliders
8. Volume Panel
9. Advanced Options

## Apply behavior
Batch apply pending changes through current safe write path only. No root. If apply unavailable, keep values saved in DeadZone and show a clear snackbar.
