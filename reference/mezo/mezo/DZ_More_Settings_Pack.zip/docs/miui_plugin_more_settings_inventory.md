# DeadZone More Settings — MiuiSystemUIPlugin Extraction Inventory

Source APK: `MiuiSystemUIPlugin.apk`  
Plugin package: `miui.systemui.plugin`  
Main menu source found: `Mahdii ;)/Menu/MenuOfMahdi.xml`  
Dex files included in pack: `5`

> This inventory is prepared for DeadZone integration. It does not modify the app. Keys must be preserved exactly.

## Extracted screenshot settings

| Category | Label | Real key candidate | Control | Type | Icon | Notes |
|---|---|---:|---|---|---|---|
| Appearance | MonetUI | `monetmode` | switch | Settings/System-like bool | `styleswitcher.png` | real key candidate from plugin strings/MenuOfMahdi; verify polarity in ROM |
| Appearance | Glass Effect | `glass_effect` | switch | bool | `styleswitcher1.png` | real key candidate |
| Appearance | Reduced Blur | `bgblur` | switch | bool | `styleswitcher2.png` | review-needed: same token may also relate to BlendBlur Sliders Icon |
| Appearance | Rounded Corners | `CustomCornerRadius` | switch | bool/int | `styleswitcher3.png` | review-needed: key name suggests corner radius behavior |
| Appearance | Compact DPI | `compactdpi` | switch | bool | `styleswitcher4.png` | real key candidate |
| Layout Styles | 4 Tiles Layout | `4tile` | switch | bool | `styleswitcher5.png` | real key candidate |
| Layout Styles | Ladder Layout | `style2` | switch | bool/enum | `styleswitcher6.png` | real key candidate; label mapping from screenshots |
| Large MediaPlayer Styles | Expanded MediaPlayer | `largemedia` | switch | bool | `styleswitcher7.png` | real key candidate |
| Large MediaPlayer Styles | Lowered MediaPlayer | `largemedia1` | switch | bool | `styleswitcher8.png` | real key candidate |
| Card Customisation | Circle Card Look | `circlecard` | switch | bool | `styleswitcher9.png` | real key candidate |
| Card Customisation | Custom Touch Effect | `cardtouch` | switch | bool | `styleswitcher10.png` | real key candidate |
| Preferences | Enable Sound Tile | `hidesound` | switch | bool | `styleswitcher11.png` | review polarity: key name says hide but UI says enable |
| Preferences | Small Device Center | `devicesize` | switch | bool | `styleswitcher12.png` | real key candidate |
| Preferences | Square Tiles | `squaretiles` | switch | bool | `styleswitcher13.png` | real key candidate |
| Edit Button Styles | Top Clock + Edit Button | `custom_clock` | switch | bool | `styleswitcher14.png` | real key candidate |
| Edit Button Styles | Default Edit Button | `defaultedit` | switch | bool | `styleswitcher15.png` | real key candidate |
| Edit Button Styles | Traffic Edit Button | `traffic` | switch | bool | `styleswitcher16.png` | real key candidate |
| Customize Sliders | Modern Slider Icons | `slidericon` | switch | bool | `styleswitcher17.png` | real key candidate |
| Customize Sliders | BlendBlur Sliders Icon | `bgblur` | switch | bool | `styleswitcher18.png` | review-needed: shares bgblur with Reduced Blur; don't map twice without polarity test |
| Customize Sliders | Percentage on Sliders | `percent` | switch | bool | `styleswitcher19.png` | real key candidate |
| Volume Panel | Small Volume Panel | `smallvolume` | switch | bool | `styleswitcher20.png` | real key candidate |
| Volume Panel | Lower Volume Panel | `columndown` | switch | bool | `styleswitcher21.png` | real key candidate |
| Volume Panel | Rounded Shortcuts | `circlebuttons` | switch | bool | `styleswitcher22.png` | real key candidate |
| Volume Panel | Hide Dnd & Silent | `HideButtons` | switch | bool | `styleswitcher23.png` | real key candidate |
| Volume Panel | Hide More Icons | `hidemore` | switch | bool | `styleswitcher24.png` | real key candidate |
| Advanced Options | Extended Hyper Island | `extended_hyper_island` | switch | bool | `styleswitcher25.png` | real key candidate |
| Advanced Options | Extended Power Menu | `powermenu` | switch | bool | `styleswitcher26.xml` | real key candidate |

## Important review notes

- `hidesound` likely has inverted polarity because the UI label is **Enable Sound Tile** while the key says **hide sound**.
- `bgblur` appears related to blur and may correspond to **Reduced Blur** and/or **BlendBlur Sliders Icon**. Do not map it twice without testing.
- Most options are switch/toggle style based on the plugin screenshots and MenuOfMahdi UI.
- Any future slider in this module must reuse the same shared DeadZone seekbar style used in Statusbar/Resize Statusbar: `DeadZoneAdjustmentRow` / `MezoSourceSeekbarRow`, not a new slider style.

## Integration safety

- No root/su.
- No package/signing/channel changes.
- No SystemUI/reference edits.
- Use existing safe settings write path only.
- If a key cannot be applied on user build, store locally and show: `Saved in DeadZone. System apply requires ROM integration.`
