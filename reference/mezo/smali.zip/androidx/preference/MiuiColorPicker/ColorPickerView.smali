# classes10.dex

.class public Landroidx/preference/MiuiColorPicker/ColorPickerView;
.super Landroid/view/View;
.source "ColorPickerView.java"

# interfaces
.implements Landroidx/preference/MiuiColorPicker/ColorPickerPresetView$OnPresetClickListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;
    }
.end annotation


# static fields
.field private static final BORDER_WIDTH_PX:F = 1.0f

.field private static final PANEL_ALPHA:I = 0x2

.field private static final PANEL_HUE:I = 0x1

.field private static final PANEL_SAT_VAL:I


# instance fields
.field private ALPHA_PANEL_HEIGHT:F

.field private HUE_PANEL_WIDTH:F

.field private PALETTE_CIRCLE_TRACKER_RADIUS:F

.field private PANEL_SPACING:F

.field private RECTANGLE_TRACKER_OFFSET:F

.field private mAlpha:I

.field private mAlphaPaint:Landroid/graphics/Paint;

.field private mAlphaPattern:Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;

.field private mAlphaRect:Landroid/graphics/RectF;

.field private mAlphaShader:Landroid/graphics/Shader;

.field private mAlphaSliderText:Ljava/lang/String;

.field private mAlphaTextPaint:Landroid/graphics/Paint;

.field private mBorderColor:I

.field private mBorderPaint:Landroid/graphics/Paint;

.field private mDensity:F

.field private mDrawingOffset:F

.field private mDrawingRect:Landroid/graphics/RectF;

.field private mHue:F

.field private mHuePaint:Landroid/graphics/Paint;

.field private mHueRect:Landroid/graphics/RectF;

.field private mHueShader:Landroid/graphics/Shader;

.field private mHueTrackerPaint:Landroid/graphics/Paint;

.field private mLastTouchedPanel:I

.field private mListener:Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;

.field private mSat:F

.field private mSatShader:Landroid/graphics/Shader;

.field private mSatValPaint:Landroid/graphics/Paint;

.field private mSatValRect:Landroid/graphics/RectF;

.field private mSatValTrackerPaint:Landroid/graphics/Paint;

.field private mShowAlphaPanel:Z

.field private mSliderTrackerColor:I

.field private mStartTouchPoint:Landroid/graphics/Point;

.field private mVal:F

.field private mValShader:Landroid/graphics/Shader;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 4

    const/4 v0, 0x0

    invoke-direct {p0, p1, p2, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 7

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/high16 v0, 0x41f00000  # 30.0f

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    const/high16 v0, 0x41a00000  # 20.0f

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    const/high16 v0, 0x41200000  # 10.0f

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    const/high16 v0, 0x40a00000  # 5.0f

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PALETTE_CIRCLE_TRACKER_RADIUS:F

    const/high16 v0, 0x40000000  # 2.0f

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->RECTANGLE_TRACKER_OFFSET:F

    const/high16 v0, 0x3f800000  # 1.0f

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    const/16 v0, 0xff

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    const/high16 v0, 0x43b40000  # 360.0f

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    iput v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    iput v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    const-string v0, ""

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaSliderText:Ljava/lang/String;

    const v0, -0xe3e3e4

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSliderTrackerColor:I

    const v0, -0x919192

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderColor:I

    iput-boolean v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    iput v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mLastTouchedPanel:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mStartTouchPoint:Landroid/graphics/Point;

    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->init()V

    return-void
.end method

.method private alphaToPoint(I)Landroid/graphics/Point;
    .registers 7

    iget-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v2

    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    int-to-float v3, p1

    mul-float/2addr v3, v2

    const/high16 v4, 0x437f0000  # 255.0f

    div-float/2addr v3, v4

    sub-float v3, v2, v3

    iget v4, v1, Landroid/graphics/RectF;->left:F

    add-float/2addr v3, v4

    float-to-int v3, v3

    iput v3, v0, Landroid/graphics/Point;->x:I

    iget v3, v1, Landroid/graphics/RectF;->top:F

    float-to-int v3, v3

    iput v3, v0, Landroid/graphics/Point;->y:I

    return-object v0
.end method

.method private buildHueColorArray()[I
    .registers 8

    const/high16 v6, 0x3f800000  # 1.0f

    const/16 v3, 0x169

    new-array v1, v3, [I

    const/4 v0, 0x0

    array-length v3, v1

    add-int/lit8 v2, v3, -0x1

    :goto_a
    if-ltz v2, :cond_24

    const/4 v3, 0x3

    new-array v3, v3, [F

    const/4 v4, 0x0

    int-to-float v5, v2

    aput v5, v3, v4

    const/4 v4, 0x1

    aput v6, v3, v4

    const/4 v4, 0x2

    aput v6, v3, v4

    invoke-static {v3}, Landroid/graphics/Color;->HSVToColor([F)I

    move-result v3

    aput v3, v1, v0

    add-int/lit8 v2, v2, -0x1

    add-int/lit8 v0, v0, 0x1

    goto :goto_a

    :cond_24
    return-object v1
.end method

.method private calculateRequiredOffset()F
    .registers 4

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PALETTE_CIRCLE_TRACKER_RADIUS:F

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->RECTANGLE_TRACKER_OFFSET:F

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v0

    const/high16 v1, 0x3f800000  # 1.0f

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    const/high16 v1, 0x3fc00000  # 1.5f

    mul-float/2addr v1, v0

    return v1
.end method

.method private chooseHeight(II)I
    .registers 4

    const/high16 v0, -0x80000000

    if-eq p1, v0, :cond_8

    const/high16 v0, 0x40000000  # 2.0f

    if-ne p1, v0, :cond_9

    :cond_8
    :goto_8
    return p2

    :cond_9
    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getPrefferedHeight()I

    move-result p2

    goto :goto_8
.end method

.method private chooseWidth(II)I
    .registers 4

    const/high16 v0, -0x80000000

    if-eq p1, v0, :cond_8

    const/high16 v0, 0x40000000  # 2.0f

    if-ne p1, v0, :cond_9

    :cond_8
    :goto_8
    return p2

    :cond_9
    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getPrefferedWidth()I

    move-result p2

    goto :goto_8
.end method

.method private drawAlphaPanel(Landroid/graphics/Canvas;)V
    .registers 18

    move-object/from16 v0, p0

    iget-boolean v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-eqz v1, :cond_12

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    if-eqz v1, :cond_12

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaPattern:Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;

    if-nez v1, :cond_13

    :cond_12
    :goto_12
    return-void

    :cond_13
    move-object/from16 v0, p0

    iget-object v12, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderPaint:Landroid/graphics/Paint;

    move-object/from16 v0, p0

    iget v2, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderColor:I

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v13, Landroid/graphics/Rect;

    iget v1, v12, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x3f800000  # 1.0f

    sub-float/2addr v1, v2

    float-to-int v1, v1

    iget v2, v12, Landroid/graphics/RectF;->top:F

    const/high16 v3, 0x3f800000  # 1.0f

    sub-float/2addr v2, v3

    float-to-int v2, v2

    iget v3, v12, Landroid/graphics/RectF;->right:F

    const/high16 v4, 0x3f800000  # 1.0f

    add-float/2addr v3, v4

    float-to-int v3, v3

    iget v4, v12, Landroid/graphics/RectF;->bottom:F

    const/high16 v5, 0x3f800000  # 1.0f

    add-float/2addr v4, v5

    float-to-int v4, v4

    invoke-direct {v13, v1, v2, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    new-instance v14, Landroid/graphics/RectF;

    invoke-direct {v14, v13}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    const/high16 v1, 0x41c80000  # 25.0f

    const/high16 v2, 0x41c80000  # 25.0f

    move-object/from16 v0, p0

    iget-object v3, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderPaint:Landroid/graphics/Paint;

    move-object/from16 v0, p1

    invoke-virtual {v0, v14, v1, v2, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaPattern:Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;

    move-object/from16 v0, p1

    invoke-virtual {v1, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v1, 0x3

    new-array v9, v1, [F

    const/4 v1, 0x0

    move-object/from16 v0, p0

    iget v2, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    aput v2, v9, v1

    const/4 v1, 0x1

    move-object/from16 v0, p0

    iget v2, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    aput v2, v9, v1

    const/4 v1, 0x2

    move-object/from16 v0, p0

    iget v2, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    aput v2, v9, v1

    invoke-static {v9}, Landroid/graphics/Color;->HSVToColor([F)I

    move-result v6

    const/4 v1, 0x0

    invoke-static {v1, v9}, Landroid/graphics/Color;->HSVToColor(I[F)I

    move-result v7

    new-instance v1, Landroid/graphics/LinearGradient;

    iget v2, v12, Landroid/graphics/RectF;->left:F

    iget v3, v12, Landroid/graphics/RectF;->top:F

    iget v4, v12, Landroid/graphics/RectF;->right:F

    iget v5, v12, Landroid/graphics/RectF;->top:F

    sget-object v8, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v1 .. v8}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    move-object/from16 v0, p0

    iput-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaShader:Landroid/graphics/Shader;

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaPaint:Landroid/graphics/Paint;

    move-object/from16 v0, p0

    iget-object v2, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaShader:Landroid/graphics/Shader;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/high16 v1, 0x41c80000  # 25.0f

    const/high16 v2, 0x41c80000  # 25.0f

    move-object/from16 v0, p0

    iget-object v3, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaPaint:Landroid/graphics/Paint;

    move-object/from16 v0, p1

    invoke-virtual {v0, v12, v1, v2, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaSliderText:Ljava/lang/String;

    if-eqz v1, :cond_d1

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaSliderText:Ljava/lang/String;

    const-string v2, ""

    if-eq v1, v2, :cond_d1

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaSliderText:Ljava/lang/String;

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerX()F

    move-result v2

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    const/high16 v4, 0x40800000  # 4.0f

    move-object/from16 v0, p0

    iget v5, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v4, v5

    add-float/2addr v3, v4

    move-object/from16 v0, p0

    iget-object v4, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaTextPaint:Landroid/graphics/Paint;

    move-object/from16 v0, p1

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    :cond_d1
    const/high16 v1, 0x40800000  # 4.0f

    move-object/from16 v0, p0

    iget v2, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v1, v2

    const/high16 v2, 0x40000000  # 2.0f

    div-float v15, v1, v2

    move-object/from16 v0, p0

    iget v1, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    move-object/from16 v0, p0

    invoke-direct {v0, v1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->alphaToPoint(I)Landroid/graphics/Point;

    move-result-object v10

    new-instance v11, Landroid/graphics/RectF;

    invoke-direct {v11}, Landroid/graphics/RectF;-><init>()V

    iget v1, v10, Landroid/graphics/Point;->x:I

    int-to-float v1, v1

    sub-float/2addr v1, v15

    iput v1, v11, Landroid/graphics/RectF;->left:F

    iget v1, v10, Landroid/graphics/Point;->x:I

    int-to-float v1, v1

    add-float/2addr v1, v15

    iput v1, v11, Landroid/graphics/RectF;->right:F

    iget v1, v12, Landroid/graphics/RectF;->top:F

    move-object/from16 v0, p0

    iget v2, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->RECTANGLE_TRACKER_OFFSET:F

    sub-float/2addr v1, v2

    iput v1, v11, Landroid/graphics/RectF;->top:F

    iget v1, v12, Landroid/graphics/RectF;->bottom:F

    move-object/from16 v0, p0

    iget v2, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->RECTANGLE_TRACKER_OFFSET:F

    add-float/2addr v1, v2

    iput v1, v11, Landroid/graphics/RectF;->bottom:F

    const/high16 v1, 0x41200000  # 10.0f

    const/high16 v2, 0x41200000  # 10.0f

    move-object/from16 v0, p0

    iget-object v3, v0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueTrackerPaint:Landroid/graphics/Paint;

    move-object/from16 v0, p1

    invoke-virtual {v0, v11, v1, v2, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    goto/16 :goto_12
.end method

.method private drawHuePanel(Landroid/graphics/Canvas;)V
    .registers 16

    iget-object v10, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueRect:Landroid/graphics/RectF;

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderPaint:Landroid/graphics/Paint;

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderColor:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v11, Landroid/graphics/Rect;

    iget v0, v10, Landroid/graphics/RectF;->left:F

    const/high16 v1, 0x3f800000  # 1.0f

    sub-float/2addr v0, v1

    float-to-int v0, v0

    iget v1, v10, Landroid/graphics/RectF;->top:F

    const/high16 v2, 0x3f800000  # 1.0f

    sub-float/2addr v1, v2

    float-to-int v1, v1

    iget v2, v10, Landroid/graphics/RectF;->right:F

    const/high16 v3, 0x3f800000  # 1.0f

    add-float/2addr v2, v3

    float-to-int v2, v2

    iget v3, v10, Landroid/graphics/RectF;->bottom:F

    const/high16 v4, 0x3f800000  # 1.0f

    add-float/2addr v3, v4

    float-to-int v3, v3

    invoke-direct {v11, v0, v1, v2, v3}, Landroid/graphics/Rect;-><init>(IIII)V

    new-instance v12, Landroid/graphics/RectF;

    invoke-direct {v12, v11}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    const/high16 v0, 0x41f00000  # 30.0f

    const/high16 v1, 0x41f00000  # 30.0f

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v12, v0, v1, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueShader:Landroid/graphics/Shader;

    if-nez v0, :cond_55

    new-instance v0, Landroid/graphics/LinearGradient;

    iget v1, v10, Landroid/graphics/RectF;->left:F

    iget v2, v10, Landroid/graphics/RectF;->top:F

    iget v3, v10, Landroid/graphics/RectF;->left:F

    iget v4, v10, Landroid/graphics/RectF;->bottom:F

    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->buildHueColorArray()[I

    move-result-object v5

    const/4 v6, 0x0

    sget-object v7, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v0 .. v7}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueShader:Landroid/graphics/Shader;

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHuePaint:Landroid/graphics/Paint;

    iget-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueShader:Landroid/graphics/Shader;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    :cond_55
    const/high16 v0, 0x41f00000  # 30.0f

    const/high16 v1, 0x41f00000  # 30.0f

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHuePaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v10, v0, v1, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/high16 v0, 0x40800000  # 4.0f

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v0, v1

    const/high16 v1, 0x40000000  # 2.0f

    div-float v13, v0, v1

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    invoke-direct {p0, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->hueToPoint(F)Landroid/graphics/Point;

    move-result-object v8

    new-instance v9, Landroid/graphics/RectF;

    invoke-direct {v9}, Landroid/graphics/RectF;-><init>()V

    iget v0, v10, Landroid/graphics/RectF;->left:F

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->RECTANGLE_TRACKER_OFFSET:F

    sub-float/2addr v0, v1

    iput v0, v9, Landroid/graphics/RectF;->left:F

    iget v0, v10, Landroid/graphics/RectF;->right:F

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->RECTANGLE_TRACKER_OFFSET:F

    add-float/2addr v0, v1

    iput v0, v9, Landroid/graphics/RectF;->right:F

    iget v0, v8, Landroid/graphics/Point;->y:I

    int-to-float v0, v0

    sub-float/2addr v0, v13

    iput v0, v9, Landroid/graphics/RectF;->top:F

    iget v0, v8, Landroid/graphics/Point;->y:I

    int-to-float v0, v0

    add-float/2addr v0, v13

    iput v0, v9, Landroid/graphics/RectF;->bottom:F

    const/high16 v0, 0x41200000  # 10.0f

    const/high16 v1, 0x41200000  # 10.0f

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueTrackerPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v9, v0, v1, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method private drawSatValPanel(Landroid/graphics/Canvas;)V
    .registers 13

    iget-object v10, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValRect:Landroid/graphics/RectF;

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderPaint:Landroid/graphics/Paint;

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderColor:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    iget v1, v0, Landroid/graphics/RectF;->left:F

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    iget v2, v0, Landroid/graphics/RectF;->top:F

    iget v0, v10, Landroid/graphics/RectF;->right:F

    const/high16 v3, 0x3f800000  # 1.0f

    add-float/2addr v3, v0

    iget v0, v10, Landroid/graphics/RectF;->bottom:F

    const/high16 v4, 0x3f800000  # 1.0f

    add-float/2addr v4, v0

    iget-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderPaint:Landroid/graphics/Paint;

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mValShader:Landroid/graphics/Shader;

    if-nez v0, :cond_39

    new-instance v0, Landroid/graphics/LinearGradient;

    iget v1, v10, Landroid/graphics/RectF;->left:F

    iget v2, v10, Landroid/graphics/RectF;->top:F

    iget v3, v10, Landroid/graphics/RectF;->left:F

    iget v4, v10, Landroid/graphics/RectF;->bottom:F

    const/4 v5, -0x1

    const/high16 v6, -0x1000000

    sget-object v7, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v0 .. v7}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mValShader:Landroid/graphics/Shader;

    :cond_39
    const/4 v0, 0x3

    new-array v0, v0, [F

    const/4 v1, 0x0

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    aput v2, v0, v1

    const/4 v1, 0x1

    const/high16 v2, 0x3f800000  # 1.0f

    aput v2, v0, v1

    const/4 v1, 0x2

    const/high16 v2, 0x3f800000  # 1.0f

    aput v2, v0, v1

    invoke-static {v0}, Landroid/graphics/Color;->HSVToColor([F)I

    move-result v6

    new-instance v0, Landroid/graphics/LinearGradient;

    iget v1, v10, Landroid/graphics/RectF;->left:F

    iget v2, v10, Landroid/graphics/RectF;->top:F

    iget v3, v10, Landroid/graphics/RectF;->right:F

    iget v4, v10, Landroid/graphics/RectF;->top:F

    const/4 v5, -0x1

    sget-object v7, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v0 .. v7}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatShader:Landroid/graphics/Shader;

    new-instance v8, Landroid/graphics/ComposeShader;

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mValShader:Landroid/graphics/Shader;

    iget-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatShader:Landroid/graphics/Shader;

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->MULTIPLY:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v8, v0, v1, v2}, Landroid/graphics/ComposeShader;-><init>(Landroid/graphics/Shader;Landroid/graphics/Shader;Landroid/graphics/PorterDuff$Mode;)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v10, v0}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    invoke-direct {p0, v0, v1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->satValToPoint(FF)Landroid/graphics/Point;

    move-result-object v9

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValTrackerPaint:Landroid/graphics/Paint;

    const/high16 v1, -0x1000000

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    iget v0, v9, Landroid/graphics/Point;->x:I

    int-to-float v0, v0

    iget v1, v9, Landroid/graphics/Point;->y:I

    int-to-float v1, v1

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PALETTE_CIRCLE_TRACKER_RADIUS:F

    const/high16 v3, 0x3f800000  # 1.0f

    iget v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v3, v4

    sub-float/2addr v2, v3

    iget-object v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValTrackerPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValTrackerPaint:Landroid/graphics/Paint;

    const v1, -0x222223

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    iget v0, v9, Landroid/graphics/Point;->x:I

    int-to-float v0, v0

    iget v1, v9, Landroid/graphics/Point;->y:I

    int-to-float v1, v1

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PALETTE_CIRCLE_TRACKER_RADIUS:F

    iget-object v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValTrackerPaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    return-void
.end method

.method private getPrefferedHeight()I
    .registers 5

    const/high16 v1, 0x43480000  # 200.0f

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v1, v2

    float-to-int v0, v1

    iget-boolean v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-eqz v1, :cond_12

    int-to-float v1, v0

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    iget v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    add-float/2addr v2, v3

    add-float/2addr v1, v2

    float-to-int v0, v1

    :cond_12
    return v0
.end method

.method private getPrefferedWidth()I
    .registers 5

    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getPrefferedHeight()I

    move-result v0

    iget-boolean v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-eqz v1, :cond_10

    int-to-float v1, v0

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    iget v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    add-float/2addr v2, v3

    sub-float/2addr v1, v2

    float-to-int v0, v1

    :cond_10
    int-to-float v1, v0

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    add-float/2addr v1, v2

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    add-float/2addr v1, v2

    float-to-int v1, v1

    return v1
.end method

.method private hueToPoint(F)Landroid/graphics/Point;
    .registers 7

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueRect:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->height()F

    move-result v0

    new-instance v1, Landroid/graphics/Point;

    invoke-direct {v1}, Landroid/graphics/Point;-><init>()V

    mul-float v3, p1, v0

    const/high16 v4, 0x43b40000  # 360.0f

    div-float/2addr v3, v4

    sub-float v3, v0, v3

    iget v4, v2, Landroid/graphics/RectF;->top:F

    add-float/2addr v3, v4

    float-to-int v3, v3

    iput v3, v1, Landroid/graphics/Point;->y:I

    iget v3, v2, Landroid/graphics/RectF;->left:F

    float-to-int v3, v3

    iput v3, v1, Landroid/graphics/Point;->x:I

    return-object v1
.end method

.method private init()V
    .registers 4

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PALETTE_CIRCLE_TRACKER_RADIUS:F

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v0, v1

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PALETTE_CIRCLE_TRACKER_RADIUS:F

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->RECTANGLE_TRACKER_OFFSET:F

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v0, v1

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->RECTANGLE_TRACKER_OFFSET:F

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v0, v1

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v0, v1

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v0, v1

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->calculateRequiredOffset()F

    move-result v0

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingOffset:F

    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->initPaintTools()V

    invoke-virtual {p0, v2}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setFocusable(Z)V

    invoke-virtual {p0, v2}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setFocusableInTouchMode(Z)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setNestedScrollingEnabled(Z)V

    return-void
.end method

.method private initPaintTools()V
    .registers 5

    const/high16 v2, 0x40000000  # 2.0f

    const/4 v3, 0x1

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValPaint:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValTrackerPaint:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHuePaint:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueTrackerPaint:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaPaint:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaTextPaint:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderPaint:Landroid/graphics/Paint;

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValTrackerPaint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValTrackerPaint:Landroid/graphics/Paint;

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValTrackerPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueTrackerPaint:Landroid/graphics/Paint;

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSliderTrackerColor:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueTrackerPaint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueTrackerPaint:Landroid/graphics/Paint;

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueTrackerPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaTextPaint:Landroid/graphics/Paint;

    const v1, -0xe3e3e4

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaTextPaint:Landroid/graphics/Paint;

    const/high16 v1, 0x41600000  # 14.0f

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaTextPaint:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaTextPaint:Landroid/graphics/Paint;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    return-void
.end method

.method private moveTrackersIfNeeded(Landroid/view/MotionEvent;)Z
    .registers 11

    const/4 v8, 0x1

    const/4 v4, 0x0

    iget-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mStartTouchPoint:Landroid/graphics/Point;

    if-nez v5, :cond_8

    move v3, v4

    :cond_7
    :goto_7
    return v3

    :cond_8
    const/4 v3, 0x0

    iget-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mStartTouchPoint:Landroid/graphics/Point;

    iget v1, v5, Landroid/graphics/Point;->x:I

    iget-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mStartTouchPoint:Landroid/graphics/Point;

    iget v2, v5, Landroid/graphics/Point;->y:I

    iget-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueRect:Landroid/graphics/RectF;

    int-to-float v6, v1

    int-to-float v7, v2

    invoke-virtual {v5, v6, v7}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_29

    iput v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mLastTouchedPanel:I

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    invoke-direct {p0, v4}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->pointToHue(F)F

    move-result v4

    iput v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    const/4 v3, 0x1

    goto :goto_7

    :cond_29
    iget-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValRect:Landroid/graphics/RectF;

    int-to-float v6, v1

    int-to-float v7, v2

    invoke-virtual {v5, v6, v7}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_4b

    iput v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mLastTouchedPanel:I

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    invoke-direct {p0, v5, v6}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->pointToSatVal(FF)[F

    move-result-object v0

    aget v4, v0, v4

    iput v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    aget v4, v0, v8

    iput v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    const/4 v3, 0x1

    goto :goto_7

    :cond_4b
    iget-object v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    if-eqz v4, :cond_7

    iget-object v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    int-to-float v5, v1

    int-to-float v6, v2

    invoke-virtual {v4, v5, v6}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_7

    const/4 v4, 0x2

    iput v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mLastTouchedPanel:I

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    float-to-int v4, v4

    invoke-direct {p0, v4}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->pointToAlpha(I)I

    move-result v4

    iput v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    const/4 v3, 0x1

    goto :goto_7
.end method

.method private pointToAlpha(I)I
    .registers 6

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v2

    float-to-int v1, v2

    int-to-float v2, p1

    iget v3, v0, Landroid/graphics/RectF;->left:F

    cmpg-float v2, v2, v3

    if-gez v2, :cond_15

    const/4 p1, 0x0

    :goto_f
    mul-int/lit16 v2, p1, 0xff

    div-int/2addr v2, v1

    rsub-int v2, v2, 0xff

    return v2

    :cond_15
    int-to-float v2, p1

    iget v3, v0, Landroid/graphics/RectF;->right:F

    cmpl-float v2, v2, v3

    if-lez v2, :cond_1e

    move p1, v1

    goto :goto_f

    :cond_1e
    iget v2, v0, Landroid/graphics/RectF;->left:F

    float-to-int v2, v2

    sub-int/2addr p1, v2

    goto :goto_f
.end method

.method private pointToHue(F)F
    .registers 6

    const/high16 v3, 0x43b40000  # 360.0f

    iget-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueRect:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v0

    iget v2, v1, Landroid/graphics/RectF;->top:F

    cmpg-float v2, p1, v2

    if-gez v2, :cond_15

    const/4 p1, 0x0

    :goto_f
    mul-float v2, p1, v3

    div-float/2addr v2, v0

    sub-float v2, v3, v2

    return v2

    :cond_15
    iget v2, v1, Landroid/graphics/RectF;->bottom:F

    cmpl-float v2, p1, v2

    if-lez v2, :cond_1d

    move p1, v0

    goto :goto_f

    :cond_1d
    iget v2, v1, Landroid/graphics/RectF;->top:F

    sub-float/2addr p1, v2

    goto :goto_f
.end method

.method private pointToSatVal(FF)[F
    .registers 10

    const/high16 v6, 0x3f800000  # 1.0f

    iget-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValRect:Landroid/graphics/RectF;

    const/4 v4, 0x2

    new-array v2, v4, [F

    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v3

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v0

    iget v4, v1, Landroid/graphics/RectF;->left:F

    cmpg-float v4, p1, v4

    if-gez v4, :cond_2c

    const/4 p1, 0x0

    :goto_16
    iget v4, v1, Landroid/graphics/RectF;->top:F

    cmpg-float v4, p2, v4

    if-gez v4, :cond_38

    const/4 p2, 0x0

    :goto_1d
    const/4 v4, 0x0

    div-float v5, v6, v3

    mul-float/2addr v5, p1

    aput v5, v2, v4

    const/4 v4, 0x1

    div-float v5, v6, v0

    mul-float/2addr v5, p2

    sub-float v5, v6, v5

    aput v5, v2, v4

    return-object v2

    :cond_2c
    iget v4, v1, Landroid/graphics/RectF;->right:F

    cmpl-float v4, p1, v4

    if-lez v4, :cond_34

    move p1, v3

    goto :goto_16

    :cond_34
    iget v4, v1, Landroid/graphics/RectF;->left:F

    sub-float/2addr p1, v4

    goto :goto_16

    :cond_38
    iget v4, v1, Landroid/graphics/RectF;->bottom:F

    cmpl-float v4, p2, v4

    if-lez v4, :cond_40

    move p2, v0

    goto :goto_1d

    :cond_40
    iget v4, v1, Landroid/graphics/RectF;->top:F

    sub-float/2addr p2, v4

    goto :goto_1d
.end method

.method private satValToPoint(FF)Landroid/graphics/Point;
    .registers 9

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValRect:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->height()F

    move-result v0

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v3

    new-instance v1, Landroid/graphics/Point;

    invoke-direct {v1}, Landroid/graphics/Point;-><init>()V

    mul-float v4, p1, v3

    iget v5, v2, Landroid/graphics/RectF;->left:F

    add-float/2addr v4, v5

    float-to-int v4, v4

    iput v4, v1, Landroid/graphics/Point;->x:I

    const/high16 v4, 0x3f800000  # 1.0f

    sub-float/2addr v4, p2

    mul-float/2addr v4, v0

    iget v5, v2, Landroid/graphics/RectF;->top:F

    add-float/2addr v4, v5

    float-to-int v4, v4

    iput v4, v1, Landroid/graphics/Point;->y:I

    return-object v1
.end method

.method private setUpAlphaRect()V
    .registers 11

    const/high16 v7, 0x3f800000  # 1.0f

    iget-boolean v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-nez v5, :cond_7

    :goto_6
    return-void

    :cond_7
    iget-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    iget v5, v1, Landroid/graphics/RectF;->left:F

    add-float v2, v5, v7

    iget v5, v1, Landroid/graphics/RectF;->bottom:F

    iget v6, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    sub-float/2addr v5, v6

    add-float v4, v5, v7

    iget v5, v1, Landroid/graphics/RectF;->bottom:F

    sub-float v0, v5, v7

    iget v5, v1, Landroid/graphics/RectF;->right:F

    sub-float v3, v5, v7

    new-instance v5, Landroid/graphics/RectF;

    invoke-direct {v5, v2, v4, v3, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    new-instance v5, Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;

    const/high16 v6, 0x40a00000  # 5.0f

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDensity:F

    mul-float/2addr v6, v7

    float-to-int v6, v6

    invoke-direct {v5, v6}, Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;-><init>(I)V

    iput-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaPattern:Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;

    iget-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaPattern:Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;

    iget-object v6, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    iget v6, v6, Landroid/graphics/RectF;->left:F

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    iget-object v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    iget v7, v7, Landroid/graphics/RectF;->top:F

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    iget-object v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    iget v8, v8, Landroid/graphics/RectF;->right:F

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    iget-object v9, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    iget v9, v9, Landroid/graphics/RectF;->bottom:F

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    invoke-virtual {v5, v6, v7, v8, v9}, Landroidx/preference/MiuiColorPicker/ColorPickerAlphaPatternDrawable;->setBounds(IIII)V

    goto :goto_6
.end method

.method private setUpHueRect()V
    .registers 10

    const/high16 v8, 0x3f800000  # 1.0f

    iget-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    iget v5, v1, Landroid/graphics/RectF;->right:F

    iget v6, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    sub-float/2addr v5, v6

    add-float v2, v5, v8

    iget v5, v1, Landroid/graphics/RectF;->top:F

    add-float v4, v5, v8

    iget v5, v1, Landroid/graphics/RectF;->bottom:F

    sub-float v6, v5, v8

    iget-boolean v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-eqz v5, :cond_2a

    iget v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    add-float/2addr v5, v7

    :goto_1c
    sub-float v0, v6, v5

    iget v5, v1, Landroid/graphics/RectF;->right:F

    sub-float v3, v5, v8

    new-instance v5, Landroid/graphics/RectF;

    invoke-direct {v5, v2, v4, v3, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueRect:Landroid/graphics/RectF;

    return-void

    :cond_2a
    const/4 v5, 0x0

    goto :goto_1c
.end method

.method private setUpSatValRect()V
    .registers 10

    const/high16 v8, 0x3f800000  # 1.0f

    iget-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v6

    const/high16 v7, 0x40000000  # 2.0f

    sub-float v3, v6, v7

    iget-boolean v6, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-eqz v6, :cond_16

    iget v6, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    add-float/2addr v6, v7

    sub-float/2addr v3, v6

    :cond_16
    iget v6, v1, Landroid/graphics/RectF;->left:F

    add-float v2, v6, v8

    iget v6, v1, Landroid/graphics/RectF;->top:F

    add-float v5, v6, v8

    add-float v0, v5, v3

    add-float v4, v2, v3

    new-instance v6, Landroid/graphics/RectF;

    invoke-direct {v6, v2, v5, v4, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v6, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatValRect:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public getAlphaSliderText()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaSliderText:Ljava/lang/String;

    return-object v0
.end method

.method public getAlphaSliderVisible()Z
    .registers 2

    iget-boolean v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    return v0
.end method

.method public getBorderColor()I
    .registers 2

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderColor:I

    return v0
.end method

.method public getColor()I
    .registers 5

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    const/4 v1, 0x3

    new-array v1, v1, [F

    const/4 v2, 0x0

    iget v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    aput v3, v1, v2

    const/4 v2, 0x1

    iget v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    aput v3, v1, v2

    const/4 v2, 0x2

    iget v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    aput v3, v1, v2

    invoke-static {v0, v1}, Landroid/graphics/Color;->HSVToColor(I[F)I

    move-result v0

    return v0
.end method

.method public getDrawingOffset()F
    .registers 2

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingOffset:F

    return v0
.end method

.method public getSliderTrackerColor()I
    .registers 2

    iget v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSliderTrackerColor:I

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 4

    const/4 v1, 0x0

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v0

    cmpg-float v0, v0, v1

    if-lez v0, :cond_15

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v0

    cmpg-float v0, v0, v1

    if-gtz v0, :cond_16

    :cond_15
    :goto_15
    return-void

    :cond_16
    invoke-direct {p0, p1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->drawSatValPanel(Landroid/graphics/Canvas;)V

    invoke-direct {p0, p1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->drawHuePanel(Landroid/graphics/Canvas;)V

    invoke-direct {p0, p1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->drawAlphaPanel(Landroid/graphics/Canvas;)V

    goto :goto_15
.end method

.method protected onMeasure(II)V
    .registers 11

    const/4 v3, 0x0

    const/4 v0, 0x0

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v5

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v2

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v4

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    invoke-direct {p0, v5, v4}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->chooseWidth(II)I

    move-result v4

    invoke-direct {p0, v2, v1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->chooseHeight(II)I

    move-result v1

    iget-boolean v6, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-nez v6, :cond_43

    int-to-float v6, v4

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    sub-float/2addr v6, v7

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    sub-float/2addr v6, v7

    float-to-int v0, v6

    if-gt v0, v1, :cond_34

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getTag()Ljava/lang/Object;

    move-result-object v6

    const-string v7, "landscape"

    invoke-virtual {v6, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_41

    :cond_34
    move v0, v1

    int-to-float v6, v0

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->PANEL_SPACING:F

    add-float/2addr v6, v7

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    add-float/2addr v6, v7

    float-to-int v3, v6

    :goto_3d
    invoke-virtual {p0, v3, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setMeasuredDimension(II)V

    return-void

    :cond_41
    move v3, v4

    goto :goto_3d

    :cond_43
    int-to-float v6, v1

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    sub-float/2addr v6, v7

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    add-float/2addr v6, v7

    float-to-int v3, v6

    if-le v3, v4, :cond_57

    move v3, v4

    int-to-float v6, v4

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->HUE_PANEL_WIDTH:F

    sub-float/2addr v6, v7

    iget v7, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->ALPHA_PANEL_HEIGHT:F

    add-float/2addr v6, v7

    float-to-int v0, v6

    goto :goto_3d

    :cond_57
    move v0, v1

    goto :goto_3d
.end method

.method public onPresetClick(I)V
    .registers 3

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setColor(IZ)V

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .registers 8

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingOffset:F

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getPaddingLeft()I

    move-result v2

    int-to-float v2, v2

    add-float/2addr v1, v2

    iput v1, v0, Landroid/graphics/RectF;->left:F

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    int-to-float v1, p1

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingOffset:F

    sub-float/2addr v1, v2

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getPaddingRight()I

    move-result v2

    int-to-float v2, v2

    sub-float/2addr v1, v2

    iput v1, v0, Landroid/graphics/RectF;->right:F

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingOffset:F

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getPaddingTop()I

    move-result v2

    int-to-float v2, v2

    add-float/2addr v1, v2

    iput v1, v0, Landroid/graphics/RectF;->top:F

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingRect:Landroid/graphics/RectF;

    int-to-float v1, p2

    iget v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mDrawingOffset:F

    sub-float/2addr v1, v2

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getPaddingBottom()I

    move-result v2

    int-to-float v2, v2

    sub-float/2addr v1, v2

    iput v1, v0, Landroid/graphics/RectF;->bottom:F

    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setUpSatValRect()V

    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setUpHueRect()V

    invoke-direct {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setUpAlphaRect()V

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 9

    const/4 v6, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2

    packed-switch v2, :pswitch_data_72

    :goto_a
    if-eqz v0, :cond_6c

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mListener:Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;

    if-eqz v2, :cond_2b

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mListener:Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;

    iget v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    const/4 v4, 0x3

    new-array v4, v4, [F

    iget v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    aput v5, v4, v6

    iget v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    aput v5, v4, v1

    const/4 v5, 0x2

    iget v6, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    aput v6, v4, v5

    invoke-static {v3, v4}, Landroid/graphics/Color;->HSVToColor(I[F)I

    move-result v3

    invoke-interface {v2, v3}, Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;->onColorChanged(I)V

    :cond_2b
    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->invalidate()V

    :goto_2e
    return v1

    :pswitch_2f  #0x0
    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    if-eqz v2, :cond_3c

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    invoke-interface {v2, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_3c
    new-instance v2, Landroid/graphics/Point;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    float-to-int v3, v3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    float-to-int v4, v4

    invoke-direct {v2, v3, v4}, Landroid/graphics/Point;-><init>(II)V

    iput-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mStartTouchPoint:Landroid/graphics/Point;

    invoke-direct {p0, p1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->moveTrackersIfNeeded(Landroid/view/MotionEvent;)Z

    move-result v0

    goto :goto_a

    :pswitch_52  #0x2
    invoke-direct {p0, p1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->moveTrackersIfNeeded(Landroid/view/MotionEvent;)Z

    move-result v0

    goto :goto_a

    :pswitch_57  #0x1
    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    if-eqz v2, :cond_64

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    invoke-interface {v2, v6}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_64
    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mStartTouchPoint:Landroid/graphics/Point;

    invoke-direct {p0, p1}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->moveTrackersIfNeeded(Landroid/view/MotionEvent;)Z

    move-result v0

    goto :goto_a

    :cond_6c
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v1

    goto :goto_2e

    nop

    :pswitch_data_72
    .packed-switch 0x0
        :pswitch_2f  #00000000
        :pswitch_57  #00000001
        :pswitch_52  #00000002
    .end packed-switch
.end method

.method public onTrackballEvent(Landroid/view/MotionEvent;)Z
    .registers 16

    const/high16 v13, 0x42480000  # 50.0f

    const/high16 v12, 0x41200000  # 10.0f

    const/high16 v11, 0x3f800000  # 1.0f

    const/4 v10, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v8

    if-nez v8, :cond_56

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getParent()Landroid/view/ViewParent;

    move-result-object v8

    if-eqz v8, :cond_24

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getParent()Landroid/view/ViewParent;

    move-result-object v8

    invoke-interface {v8, v7}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_24
    :goto_24
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v8

    const/4 v9, 0x2

    if-ne v8, v9, :cond_30

    iget v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mLastTouchedPanel:I

    packed-switch v8, :pswitch_data_d4

    :cond_30
    :goto_30
    if-eqz v3, :cond_ce

    iget-object v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mListener:Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;

    if-eqz v8, :cond_52

    iget-object v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mListener:Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;

    iget v9, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    const/4 v10, 0x3

    new-array v10, v10, [F

    const/4 v11, 0x0

    iget v12, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    aput v12, v10, v11

    iget v11, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    aput v11, v10, v7

    const/4 v11, 0x2

    iget v12, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    aput v12, v10, v11

    invoke-static {v9, v10}, Landroid/graphics/Color;->HSVToColor(I[F)I

    move-result v9

    invoke-interface {v8, v9}, Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;->onColorChanged(I)V

    :cond_52
    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->invalidate()V

    :goto_55
    return v7

    :cond_56
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v8

    if-ne v8, v7, :cond_24

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getParent()Landroid/view/ViewParent;

    move-result-object v8

    if-eqz v8, :cond_24

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getParent()Landroid/view/ViewParent;

    move-result-object v8

    const/4 v9, 0x0

    invoke-interface {v8, v9}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    goto :goto_24

    :pswitch_6b  #0x0
    iget v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    div-float v9, v5, v13

    add-float v2, v8, v9

    iget v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    div-float v9, v6, v13

    sub-float v4, v8, v9

    cmpg-float v8, v2, v10

    if-gez v8, :cond_87

    const/4 v2, 0x0

    :cond_7c
    :goto_7c
    cmpg-float v8, v4, v10

    if-gez v8, :cond_8e

    const/4 v4, 0x0

    :cond_81
    :goto_81
    iput v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    iput v4, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    const/4 v3, 0x1

    goto :goto_30

    :cond_87
    cmpl-float v8, v2, v11

    if-lez v8, :cond_7c

    const/high16 v2, 0x3f800000  # 1.0f

    goto :goto_7c

    :cond_8e
    cmpl-float v8, v4, v11

    if-lez v8, :cond_81

    const/high16 v4, 0x3f800000  # 1.0f

    goto :goto_81

    :pswitch_95  #0x1
    iget v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    mul-float v9, v6, v12

    sub-float v1, v8, v9

    cmpg-float v8, v1, v10

    if-gez v8, :cond_a4

    const/4 v1, 0x0

    :cond_a0
    :goto_a0
    iput v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    const/4 v3, 0x1

    goto :goto_30

    :cond_a4
    const/high16 v8, 0x43b40000  # 360.0f

    cmpl-float v8, v1, v8

    if-lez v8, :cond_a0

    const/high16 v1, 0x43b40000  # 360.0f

    goto :goto_a0

    :pswitch_ad  #0x2
    iget-boolean v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-eqz v8, :cond_b5

    iget-object v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaRect:Landroid/graphics/RectF;

    if-nez v8, :cond_b8

    :cond_b5
    const/4 v3, 0x0

    goto/16 :goto_30

    :cond_b8
    iget v8, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    int-to-float v8, v8

    mul-float v9, v5, v12

    sub-float/2addr v8, v9

    float-to-int v0, v8

    if-gez v0, :cond_c7

    const/4 v0, 0x0

    :cond_c2
    :goto_c2
    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    const/4 v3, 0x1

    goto/16 :goto_30

    :cond_c7
    const/16 v8, 0xff

    if-le v0, v8, :cond_c2

    const/16 v0, 0xff

    goto :goto_c2

    :cond_ce
    invoke-super {p0, p1}, Landroid/view/View;->onTrackballEvent(Landroid/view/MotionEvent;)Z

    move-result v7

    goto :goto_55

    nop

    :pswitch_data_d4
    .packed-switch 0x0
        :pswitch_6b  #00000000
        :pswitch_95  #00000001
        :pswitch_ad  #00000002
    .end packed-switch
.end method

.method public setAlphaSliderText(I)V
    .registers 4

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setAlphaSliderText(Ljava/lang/String;)V

    return-void
.end method

.method public setAlphaSliderText(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaSliderText:Ljava/lang/String;

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->invalidate()V

    return-void
.end method

.method public setAlphaSliderVisible(Z)V
    .registers 4

    const/4 v1, 0x0

    iget-boolean v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    if-eq v0, p1, :cond_12

    iput-boolean p1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mShowAlphaPanel:Z

    iput-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mValShader:Landroid/graphics/Shader;

    iput-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSatShader:Landroid/graphics/Shader;

    iput-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueShader:Landroid/graphics/Shader;

    iput-object v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlphaShader:Landroid/graphics/Shader;

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->requestLayout()V

    :cond_12
    return-void
.end method

.method public setBorderColor(I)V
    .registers 2

    iput p1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mBorderColor:I

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->invalidate()V

    return-void
.end method

.method public setColor(I)V
    .registers 3

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->setColor(IZ)V

    return-void
.end method

.method public setColor(IZ)V
    .registers 12

    const/4 v4, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-static {p1}, Landroid/graphics/Color;->alpha(I)I

    move-result v0

    new-array v1, v4, [F

    invoke-static {p1, v1}, Landroid/graphics/Color;->colorToHSV(I[F)V

    iput v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    aget v2, v1, v6

    iput v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    aget v2, v1, v7

    iput v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    aget v2, v1, v8

    iput v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    if-eqz p2, :cond_3a

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mListener:Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;

    if-eqz v2, :cond_3a

    iget-object v2, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mListener:Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;

    iget v3, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mAlpha:I

    new-array v4, v4, [F

    iget v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHue:F

    aput v5, v4, v6

    iget v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSat:F

    aput v5, v4, v7

    iget v5, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mVal:F

    aput v5, v4, v8

    invoke-static {v3, v4}, Landroid/graphics/Color;->HSVToColor(I[F)I

    move-result v3

    invoke-interface {v2, v3}, Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;->onColorChanged(I)V

    :cond_3a
    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->invalidate()V

    return-void
.end method

.method public setOnColorChangedListener(Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;)V
    .registers 2

    iput-object p1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mListener:Landroidx/preference/MiuiColorPicker/ColorPickerView$OnColorChangedListener;

    return-void
.end method

.method public setSliderTrackerColor(I)V
    .registers 4

    iput p1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSliderTrackerColor:I

    iget-object v0, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mHueTrackerPaint:Landroid/graphics/Paint;

    iget v1, p0, Landroidx/preference/MiuiColorPicker/ColorPickerView;->mSliderTrackerColor:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p0}, Landroidx/preference/MiuiColorPicker/ColorPickerView;->invalidate()V

    return-void
.end method
