# classes10.dex

.class Landroidx/preference/XMiuiSeekBarPreference$SavedState;
.super Landroidx/preference/Preference$BaseSavedState;
.source "XMiuiSeekBarPreference.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/preference/XMiuiSeekBarPreference;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "SavedState"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator",
            "<",
            "Landroidx/preference/XMiuiSeekBarPreference$SavedState;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field mMax:I

.field mMin:I

.field mSeekBarValue:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Landroidx/preference/XMiuiSeekBarPreference$SavedState$1;

    invoke-direct {v0}, Landroidx/preference/XMiuiSeekBarPreference$SavedState$1;-><init>()V

    sput-object v0, Landroidx/preference/XMiuiSeekBarPreference$SavedState;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method constructor <init>(Landroid/os/Parcel;)V
    .registers 3

    invoke-direct {p0, p1}, Landroidx/preference/Preference$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroidx/preference/XMiuiSeekBarPreference$SavedState;->mSeekBarValue:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroidx/preference/XMiuiSeekBarPreference$SavedState;->mMin:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroidx/preference/XMiuiSeekBarPreference$SavedState;->mMax:I

    return-void
.end method

.method constructor <init>(Landroid/os/Parcelable;)V
    .registers 2

    invoke-direct {p0, p1}, Landroidx/preference/Preference$BaseSavedState;-><init>(Landroid/os/Parcelable;)V

    return-void
.end method


# virtual methods
.method public writeToParcel(Landroid/os/Parcel;I)V
    .registers 4

    invoke-super {p0, p1, p2}, Landroidx/preference/Preference$BaseSavedState;->writeToParcel(Landroid/os/Parcel;I)V

    iget v0, p0, Landroidx/preference/XMiuiSeekBarPreference$SavedState;->mSeekBarValue:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    iget v0, p0, Landroidx/preference/XMiuiSeekBarPreference$SavedState;->mMin:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    iget v0, p0, Landroidx/preference/XMiuiSeekBarPreference$SavedState;->mMax:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method
