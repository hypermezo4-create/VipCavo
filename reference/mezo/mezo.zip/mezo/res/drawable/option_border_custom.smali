<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:id="@id/shape">
        <shape android:shape="rectangle">
            <solid android:color="@color/signals_bg_color" />
            <corners android:radius="15dp" />
        </shape>
    </item>
    <item android:drawable="@drawable/option_border_edge_custom" />
</layer-list>
